import "./App.css";
import Layout from "./component/Layout/Layout";

function App() {
  return <Layout/>;
}

export default App;
